import { destinations } from "./destinations";

export const CATEGORIES = [
  { id: "destination", label: "Điểm đến", href: "/explore?cat=destination", icon: "MapPin" },
  { id: "accommodation", label: "Lưu trú", href: "/explore?cat=accommodation", icon: "Bed" },
  { id: "restaurant", label: "Ăn uống", href: "/explore?cat=restaurant", icon: "Food" },
  { id: "activity", label: "Hoạt động", href: "/explore?cat=activity", icon: "Activity" },
  { id: "ticket", label: "Vé", href: "/explore?cat=ticket", icon: "Ticket" },
  { id: "transport", label: "Di chuyển", href: "/explore?cat=transport", icon: "Compass" },
];

const destinationItems = destinations.map((d) => ({
  id: d.slug,
  cat: "destination",
  name: d.name,
  area: d.area,
  image: d.image,
  imageFallback: d.imageFallback,
  alt: d.alt,
  price: d.visit?.price || "Xem chi tiết",
  level: d.access.level,
  note: d.access.status,
  audio: d.audio,
  summary: d.summary,
  verifiedPlace: true,
  destinationSlug: d.slug,
}));

// Các mục dưới đây chỉ để minh hoạ workflow booking/Business theo requirement.
// Không đại diện cho một nhà cung cấp thực tế và không được gắn nhãn "verified".
const demoServices = [
  { id: "demo-hotel", cat: "accommodation", name: "Phòng lưu trú tiếp cận — DEMO", area: "Hà Nội", imageFallback: "/assets/images/we-ai-luu-tru-phong.jpg", image: "/assets/images/we-ai-luu-tru-phong.jpg", alt: "Phòng nghỉ phong cách nhà cổ Hà Nội, ảnh AI minh họa dịch vụ lưu trú demo.", price: "Giá demo", level: "Chưa xác minh", note: "Dữ liệu mô phỏng để thử luồng Accommodation Booking và Accessibility Request.", audio: "Đây là dịch vụ lưu trú minh họa. Thông tin giá, phòng và tiện ích chưa phải dữ liệu của một cơ sở thật.", summary: "Mục minh họa luồng tìm phòng, accessibility request và booking.", isDemo: true },
  { id: "demo-restaurant", cat: "restaurant", name: "Nhà hàng tiếp cận — DEMO", area: "Hà Nội", imageFallback: "/assets/images/we-ai-an-uong-nha-hang.jpg", image: "/assets/images/we-ai-an-uong-nha-hang.jpg", alt: "Không gian nhà hàng kiểu Việt, ảnh AI minh họa dịch vụ ăn uống demo.", price: "Giá demo", level: "Chưa xác minh", note: "Dữ liệu mô phỏng; Business phải khai báo và Admin có thể kiểm duyệt trước khi hiển thị thật.", audio: "Đây là mục ăn uống minh họa. Không có tuyên bố accessibility nào được coi là đã xác minh.", summary: "Mục minh họa dịch vụ ăn uống trong nền tảng.", isDemo: true },
  { id: "demo-guide-tour", cat: "activity", name: "Tour có Guide/Assistant — DEMO", area: "Hà Nội", imageFallback: "/assets/images/we-ai-tour-huong-dan.jpg", image: "/assets/images/we-ai-tour-huong-dan.jpg", alt: "Nhóm du khách và hướng dẫn viên đi bộ tại khu phố cũ, ảnh AI minh họa tour demo.", price: "Giá demo", level: "Chưa xác minh", note: "Minh họa chức năng tìm Guide/Assistant, xem availability và gửi nhu cầu hỗ trợ.", audio: "Đây là tour minh họa để thử luồng Guide và Personal Assistant.", summary: "Mục minh họa đặt Guide/Personal Assistant.", isDemo: true },
  { id: "ve-van-mieu", cat: "ticket", name: "Vé Văn Miếu – Quốc Tử Giám", area: "Đống Đa, Hà Nội", imageFallback: "/assets/images/we-ticket-van-mieu-demo.jpg", image: "/assets/images/we-ticket-van-mieu-demo.jpg", alt: "Hình thiết kế vé tham quan Văn Miếu - Quốc Tử Giám, chỉ minh họa, không phải vé được phát hành.", price: "70.000đ vé tiêu chuẩn (theo nguồn chính thức đã đối chiếu)", level: "Dữ liệu một phần", note: "Nguồn chính thức liệt kê thiết bị thuyết minh; các tiêu chí accessibility khác cần xác minh.", audio: destinations[1].audio, summary: "Mục vé gắn với địa điểm thật; kiểm tra lại chính sách tại thời điểm đặt.", verifiedPlace: true, destinationSlug: "van-mieu" },
  { id: "ve-mua-roi", cat: "ticket", name: "Nhà hát Múa rối Thăng Long", area: "Hoàn Kiếm, Hà Nội", imageFallback: "/assets/images/we-ticket-mua-roi-demo.jpg", image: "/assets/images/we-ticket-mua-roi-demo.jpg", alt: "Hình minh họa vé trải nghiệm múa rối nước, không phải vé được phát hành.", price: "Tùy hạng vé / suất diễn", level: "Cần xác minh", note: "Địa chỉ đã đối chiếu; không mặc định có audio description hoặc lối tiếp cận nếu chưa được nhà hát xác nhận.", audio: destinations[5].audio, summary: "Kiểm tra lịch diễn và hạng vé trên kênh chính thức trước khi đặt.", verifiedPlace: true, destinationSlug: "mua-roi-thang-long" },
  { id: "demo-transport", cat: "transport", name: "Phương tiện hỗ trợ — DEMO", area: "Hà Nội", imageFallback: "/assets/images/we-ai-xe-dien-du-lich.jpg", image: "/assets/images/we-ai-xe-dien-du-lich.jpg", alt: "Xe điện chở du khách trên phố, ảnh AI minh họa dịch vụ di chuyển demo.", price: "Giá demo", level: "Chưa xác minh", note: "Minh họa pickup/drop-off, accessibility request và trạng thái chuyến.", audio: "Đây là dịch vụ phương tiện minh họa, không phải một hãng vận tải thật.", summary: "Mục minh họa Transport Booking.", isDemo: true },
];

export const catalog = [...destinationItems, ...demoServices];
export function byCategory(cat) { return cat ? catalog.filter((x) => x.cat === cat) : catalog; }
export function getItem(id) { return catalog.find((x) => x.id === id) || null; }
export function catLabel(cat) { return CATEGORIES.find((c) => c.id === cat)?.label || "Mục"; }
