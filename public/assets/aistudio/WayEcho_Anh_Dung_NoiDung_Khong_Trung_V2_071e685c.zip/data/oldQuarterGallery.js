// Ảnh local gồm ảnh dự án và ảnh AI minh họa (mô tả theo từng ảnh); không phải toàn bộ ảnh tư liệu thực tế.
// Khi phát hành cần kiểm tra quyền của các ảnh nguồn dự án; minh họa AI không phải ảnh chứng thực hiện trạng.
export const oldQuarterGallery = [
  {
    "name": "Phố cổ Hà Nội",
    "image": "/assets/images/we-photo-pho-co-do-thi.jpg",
    "source": null,
    "href": "/articles",
    "alt": "Ảnh chụp tổng quan đường phố Hà Nội"
  },
  {
    "name": "Phố Tạ Hiện",
    "image": "/assets/images/we-ai-pho-ta-hien.jpg",
    "source": null,
    "href": "/articles",
    "alt": "Ảnh AI minh họa không gian phố Tạ Hiện"
  },
  {
    "name": "Phố Hàng Bạc",
    "image": "/assets/images/we-ai-nghe-kim-hoan.jpg",
    "source": null,
    "href": "/destination?d=pho-co",
    "alt": "Ảnh AI minh họa nghề kim hoàn gắn với phố Hàng Bạc"
  },
  {
    "name": "Ngõ phố cổ Hà Nội",
    "image": "/assets/images/we-photo-ngo-pho-co.jpg",
    "source": null,
    "href": "/articles",
    "alt": "Ảnh chụp ngõ trong khu phố cổ, không xác nhận là phố Hàng Gai"
  },
  {
    "name": "Phố Hàng Đào",
    "image": "/assets/images/we-ai-pho-hang-dao.jpg",
    "source": null,
    "href": "/articles",
    "alt": "Ảnh AI minh họa không gian phố Hàng Đào"
  },
  {
    "name": "Góc phố Hà Nội",
    "image": "/assets/images/we-photo-pho-co-goc-pho.jpg",
    "source": null,
    "href": "/articles",
    "alt": "Ảnh chụp góc phố Hà Nội, không xác nhận là Hàng Bồ"
  },
  {
    "name": "Phố cổ về đêm",
    "image": "/assets/images/we-photo-pho-ta-hien-ban-dem.jpg",
    "source": null,
    "href": "/articles",
    "alt": "Ảnh chụp phố cổ về đêm, không xác nhận là Tạ Hiện"
  },
  {
    "name": "Nhịp sống phố cổ",
    "image": "/assets/images/we-photo-doi-song-pho-co.jpg",
    "source": null,
    "href": "/articles",
    "alt": "Ảnh chụp hoạt động giao thông và sinh hoạt ở phố cổ Hà Nội"
  },
  {
    "name": "Chợ phố cổ",
    "image": "/assets/images/we-photo-cho-dem.jpg",
    "source": null,
    "href": "/articles/cho-dong-xuan",
    "alt": "Ảnh chụp chợ đêm trong khu vực phố cổ"
  },
  {
    "name": "Phố cổ và gánh hàng rong",
    "image": "/assets/images/we-photo-nguoi-ban-hang-rong.jpg",
    "source": null,
    "href": "/articles",
    "alt": "Ảnh chụp người bán hàng rong trên đường phố Hà Nội"
  },
  {
    "name": "Cửa Ô Quan Chưởng",
    "image": "/assets/images/we-ai-o-quan-chuong.jpg",
    "source": null,
    "href": "/articles/o-quan-chuong",
    "alt": "Ảnh AI minh họa cửa ô Quan Chưởng"
  },
  {
    "name": "Chợ Đồng Xuân",
    "image": "/assets/images/we-ai-cho-dong-xuan.jpg",
    "source": null,
    "href": "/articles/cho-dong-xuan",
    "alt": "Ảnh AI minh họa mặt tiền chợ Đồng Xuân"
  }
];
