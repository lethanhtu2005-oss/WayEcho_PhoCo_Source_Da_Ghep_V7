# WayEcho - Bộ sửa hình ảnh V2

Đây là gói **ảnh + file source sửa đường dẫn**, không phải ZIP của cả ứng dụng.

## Cài đặt
1. Giải nén ZIP vào THƯ MỤC GỐC source WayEcho (nơi có `app`, `data`, `public`).
2. Cho phép ghi đè 11 file trong `app/`, `data/`, `components/` và bổ sung ảnh vào `public/assets/images/`.
3. Kiểm tra `npm install`, `npm run build`, `npm run dev` trên máy trước khi commit.
4. Deploy lại trên Vercel. Không xóa các file khác trong source.

## Đã sửa
- 7 thẻ địa điểm trong catalog (kèm ảnh và fallback local), sửa Văn Miếu gán nhầm ảnh tháp chùa.
- 6 sản phẩm Dịch vụ/Vé dùng hình riêng, sửa phòng khách sạn/nhà hàng/tour/xe/vé.
- 4 thẻ điểm nổi bật trang chủ, 4 bài blog theo địa điểm.
- 12 ảnh trong carousel Khám phá qua hình ảnh dùng đường dẫn local (không phụ thuộc CDN Commons).
- 20 blog SEO giữ hình Commons chính, thêm hình dự phòng AI cho từng bài khi ảnh ngoài lỗi.
- 3 ảnh phù hợp chức năng chỉ đường/camera/hỗ trợ con người ở trang chủ và ảnh demo Văn Miếu tại trợ lý AI.

## Giới hạn quan trọng
- Một số ảnh là **AI minh họa**, không phải ảnh xác thực công trình/đối tác; trường `alt` đã nêu rõ.
- Ảnh local cũ từ dự án chưa có giấy phép/tác giả xác minh trong gói này; cần rà soát quyền trước khi phát hành công khai.
- Không thể kiểm tra trực tiếp Vercel/GitHub trong môi trường hiện tại. Đây là bản sửa theo source hiện có trong phiên, cần so sánh với branch đang deploy trước khi ghi đè.
- Có thể có chỗ dùng lặp **chủ đề** trong cùng trang (vd. một địa điểm được liên kết tới một bài blog), nhưng không có hai file ảnh trong gói giống hệt về dữ liệu.

